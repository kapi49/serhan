./nsgpucnminer
